create procedure coverRename()
BEGIN
	DECLARE stop_flag int DEFAULT 0;
	DECLARE iid int default 0;
	DECLARE id_list CURSOR for select id from t_textbook_dubbing_resource ;
	declare CONTINUE HANDLER FOR SQLSTATE '02000' SET stop_flag=1;
	open id_list;

	while stop_flag <> 1  do
		 fetch id_list into iid;
		 update t_textbook_dubbing_resource set coverImg = replace(coverImg,substring_index(coverImg,'/',-1),'01.jpg') where id = iid;
	end while;

	close id_list;
END;

