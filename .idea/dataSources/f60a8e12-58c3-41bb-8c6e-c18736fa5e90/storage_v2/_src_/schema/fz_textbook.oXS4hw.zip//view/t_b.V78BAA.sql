create view t_b as
select `fz_textbook`.`t_textbook_module`.`bookId`                               AS `bookId`,
       group_concat(`fz_textbook`.`t_textbook_module`.`moduleId` separator ',') AS `moduleL`,
       group_concat(`fz_textbook`.`t_textbook_module`.`status` separator ',')   AS `statusL`
from `fz_textbook`.`t_textbook_module`
where (`fz_textbook`.`t_textbook_module`.`status` <> 0)
group by `fz_textbook`.`t_textbook_module`.`bookId`;

