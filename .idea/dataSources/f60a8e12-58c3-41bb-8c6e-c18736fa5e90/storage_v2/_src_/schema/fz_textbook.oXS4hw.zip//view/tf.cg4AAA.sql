create view tf as
select `a`.`id`        AS `id`,
       `a`.`catalogId` AS `catalogId`,
       `a`.`sortNum`   AS `sortNum`,
       `a`.`sonNum`    AS `sonNum`,
       `a`.`content`   AS `content`,
       `b`.`bookId`    AS `bookId`
from `fz_textbook`.`t_textbook_catalogue_follow` `a`
       join `fz_textbook`.`t_textbook_catalogue` `b`
where (`a`.`catalogId` = `b`.`id`);

