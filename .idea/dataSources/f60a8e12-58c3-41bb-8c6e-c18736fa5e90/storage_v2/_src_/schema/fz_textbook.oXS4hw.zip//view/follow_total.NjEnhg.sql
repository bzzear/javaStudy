create view follow_total as
select count(0) AS `count`,`b`.`bookId` AS `bookId`
from (`fz_textbook`.`t_textbook_catalogue_follow` `a`
       left join `fz_textbook`.`t_textbook_catalogue` `b` on ((`a`.`catalogId` = `b`.`id`)))
where (`a`.`status` <> 2)
group by `b`.`bookId`;

